import * as React from "react";
import { Image } from "expo-image";
import {
  StyleSheet,
  Text,
  View,
  Pressable,
  TouchableOpacity,
  ScrollView,
} from "react-native";
import { useNavigation } from "@react-navigation/native";

const MENTORSCREEN2 = ({ route }) => {
  const navigation = useNavigation();
  const { userID, profileID, profileType } = route.params;

  console.log("test3");

  return (
    <ScrollView contentContainerStyle={styles.scrollViewContent}>
      <View style={[styles.optScreen, styles.optScreenFlexBox]}>
        <Image
          style={styles.header1Icon}
          contentFit="cover"
          source={require("../assets/header-1.png")}
        />
        <View style={styles.info}>
          <Text style={[styles.mentorMatching, styles.viewDetailsTypo]}>
            Mentor Matching
          </Text>
          <Text style={styles.mentorMatchingAllowsContainer}>
            <Text
              style={styles.mentorMatchingAllows}
            >{`Mentor Matching allows you to connect with and receive education from a team of high-level experts and leaders.  

Opting in will allow you to select through recommended mentors based on your interests and skills. 

`}</Text>
            <Text style={[styles.letsGetStarted, styles.viewDetailsTypo]}>
              Let's get started!
            </Text>
          </Text>
        </View>
        <Pressable
          style={styles.buttonPrimaryWrapper}
          //onPress={() => navigation.navigate("MATCHINGSCREEN1")} - doesnt do anything?
        >
          <TouchableOpacity
            style={[styles.buttonPrimary, styles.optScreenFlexBox]}
            activeOpacity={0.2}
            //onPress={() => navigation.navigate("MATCHINGSCREEN1", { userID, profileID, profileType })}
            onPress={() => navigation.navigate("MATCHINGSCREEN1")}
          >
            <Text style={[styles.viewDetails, styles.viewDetailsTypo]}>
              Opt-in
            </Text>
          </TouchableOpacity>
        </Pressable>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  scrollViewContent: {
    flexGrow: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  optScreenFlexBox: {
    justifyContent: "center",
    alignItems: "center",
    flex: 1,
  },
  viewDetailsTypo: {
    fontFamily: "Raleway-Bold",
    fontWeight: "700",
  },
  header1Icon: {
    width: 330,
    height: 270,
  },
  mentorMatching: {
    fontSize: 32,
    textAlign: "left",
    color: "#000",
  },
  mentorMatchingAllows: {
    fontSize: 15,
    lineHeight: 23,
    fontFamily: "Raleway-Regular",
    color: "#000",
  },
  letsGetStarted: {
    fontSize: 16,
    color: "#fa0066",
  },
  mentorMatchingAllowsContainer: {
    textAlign: "left",
    alignSelf: "stretch",
  },
  info: {
    overflow: "hidden",
    gap: 20,
    alignSelf: "stretch",
  },
  viewDetails: {
    fontSize: 18,
    color: "#fff",
    textAlign: "center",
  },
  buttonPrimary: {
    borderRadius: 5,
    backgroundColor: "#ed469a",
    paddingHorizontal: 20,
    paddingVertical: 10,
    alignSelf: "flex-start",
    flexDirection: "row",
  },
  buttonPrimaryWrapper: {
    flexDirection: "row",
    alignSelf: "stretch",
  },
  optScreen: {
    flex: 1,
    width: "100%",
    paddingHorizontal: 30,
    paddingTop: "20%",
    paddingBottom: "20%",
    gap: 30,
    justifyContent: "center",
  },
});

export default MENTORSCREEN2;
